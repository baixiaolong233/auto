# encoding=utf-8
import random
from playwright.async_api import Page, TimeoutError
from modules.logger import Logger

logger = Logger()


# 视频区域内移动鼠标
async def move_mouse(page: Page):
    try:
        await page.wait_for_selector(".videoArea", state="attached", timeout=5000)
        elem = page.locator(".videoArea")
        await elem.hover(timeout=4000)
        pos = await elem.bounding_box()
        if not pos:
            return
        # Calculate the target position to move the mouse
        target_x = pos['x'] + random.uniform(-10, 10)
        target_y = pos['y'] + random.uniform(-10, 10)
        await page.mouse.move(target_x, target_y)
    except TimeoutError:
        return


async def get_course_progress(page: Page, is_new_version=False, is_hike_class=False, is_collapse_class=False):
    curtime = "0%"
    await move_mouse(page)

    # 1. 针对 .el-collapse-item 课程（核心修复：直接读视频进度）
    if is_collapse_class:
        try:
            # 直接读取视频当前时间和总时长（这是最准确的判断标准）
            current_time = await page.evaluate("""() => {
                const video = document.querySelector('video');
                if (video) {
                    return { current: video.currentTime, total: video.duration };
                }
                return { current: 0, total: 1 };
            }""")
            
            # 如果视频播放完毕（允许 1秒误差）
            if current_time['current'] > current_time['total'] - 1:
                return "100%"
            
            # 否则读取环形进度条文本作为显示（视觉进度）
            progress_text = await page.evaluate("""() => {
                const textEl = document.querySelector('.el-progress__text');
                if (textEl) return textEl.innerText.replace('%', '').trim();
                return '0';
            }""")
            
            return f"{progress_text}%"
            
        except Exception as e:
            logger.warn(f"获取新课进度失败: {e}")
            return "0%"

    # 2. 原来的徒步课逻辑（不变）
    elif is_hike_class:
        cur_play = await page.query_selector(".file-item.active")
        if cur_play:
            progress = await cur_play.query_selector(".rate")
            if progress:
                curtime = (await progress.text_content()).strip()
            else:
                # Fallback: 检查是否有完成图标
                finish = await cur_play.query_selector(".icon-finish")
                if finish:
                    curtime = "100%"

    # 3. 原来的普通课逻辑（不变）
    else:
        cur_play = await page.query_selector(".current_play")
        if cur_play:
            progress = await cur_play.query_selector(".progress-num")
            if progress:
                curtime = (await progress.text_content()).strip()
            else:
                if is_new_version:
                    progress_ele = await cur_play.query_selector(".progress-num")
                    if progress_ele:
                        progress = await progress_ele.text_content()
                        curtime = progress
                else:
                    finish = await cur_play.query_selector(".time_icofinish")
                    if finish:
                        curtime = "100%"

    return curtime
# 打印课程播放进度
def show_course_progress(desc, cur_time=None, limit_time=0):
    assert limit_time >= 0, "limit_time 必须为非负数!"
    if limit_time == 0:
        cur_time = "0%" if cur_time == '' or cur_time is None else cur_time
        if isinstance(cur_time, (int, float)):
            percent = int(cur_time)
        else:
            percent = int(str(cur_time).split("%")[0]) + 1
        if percent >= 80:
            percent = 100
        percent = max(0, min(percent, 100))
        length = int(percent * 30 // 100)
        progress = ("█" * length).ljust(30, " ")
        print(f"\r{desc} |{progress}| {percent}%\t".ljust(50), end="", flush=True)
    else:
        cur_time = 0 if cur_time == '' or cur_time is None else cur_time
        if isinstance(cur_time, str):
            cur_time = 0
        left_time = round(limit_time - cur_time, 1)
        percent = int(cur_time / limit_time * 100)
        if left_time <= 0:
            percent = 100
        percent = max(0, min(percent, 100))
        length = int(percent * 20 // 100)
        progress = ("█" * length).ljust(20, " ")
        print(f"\r{desc} |{progress}| {percent}%\t剩余 {left_time} min\t".ljust(50), end="", flush=True)


# 打印通用版进度条
def show_progress(desc, current, total, suffix="", width=30):
    percent = int(current / total * 100)
    length = int(percent * width // 100)
    progress = ("█" * length).ljust(width, " ")
    print(f"\r{desc} |{progress}| {percent}%\t{suffix}".ljust(50), end="", flush=True)
